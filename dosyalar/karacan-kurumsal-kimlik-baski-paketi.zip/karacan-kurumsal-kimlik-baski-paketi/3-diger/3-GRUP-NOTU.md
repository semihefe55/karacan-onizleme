# Karacan kurumsal kimlik — 3. grup

| Dosya | Ölçü | Not |
|---|---|---|
| `makbuz/karacan-aidat-makbuzu-210x99.pdf` | 210 × 99 mm (A4'ün üçte biri) | Matbaada numaralı, koçanlı (asıl + suret) cilt olarak bastırılır; numaratörü matbaa ekler. |
| `makbuz/karacan-aidat-makbuzu-A4-3lu.pdf` | A4, 3 makbuz | Ofis yazıcısından basıp kesik çizgilerden kesmek için. |
| `yaka-karti/karacan-yaka-karti-54x86.pdf` | 54 × 86 mm + 3 mm taşma (60 × 92) | 1. sayfa ön, 2. sayfa arka. PVC kart ya da kâğıt + laminasyon. Personel listesi (ad, görev, görev yeri, fotoğraf) gelince kişiye özel kartlar üretilir. |
| `bloknot/karacan-bloknot-A5.pdf` | 148 × 210 mm | Beyaz kâğıt, 50 yapraklık bloknot. Taşma payı gerekmez. |
| `tabela/karacan-kapi-levhasi-300x100.pdf` | 300 × 100 mm | Pleksi, fırçalı metal ya da dibond. |
| `tabela/karacan-cephe-tabelasi-1500x500.pdf` | 1500 × 500 mm, vektör | Ölçek bozulmadan istenen boya büyütülür; kutu harf / ışıklı üretim tabelacıyla konuşulur. Ofis adresi ve cephe ölçüsü belli olunca uyarlanır. |

Makbuz notu: Makbuz, ilgili site/apartman yönetimi adına düzenlenir; vergi belgesi yerine geçmez. Karacan'ın kendi hizmet bedeli için ayrıca fatura kesilir. Kullanım şeklini muhasebeciyle teyit edin.

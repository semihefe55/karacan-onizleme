# Karacan kurumsal kimlik — 1. grup (kırtasiye)

## Antetli kâğıt (A4)
| Dosya | Ne için |
|---|---|
| `antetli/karacan-antetli-sablon.docx` | Word şablonu. Yazışma ve teklifler bilgisayarda yazılır. Yazı tipleri dosyanın içine gömülü; bilgisayarda kurulu olmasa da doğru görünür. Google Dokümanlar'da da açılır (Inter ve Playfair orada hazır). |
| `antetli/karacan-antetli-baski-A4.pdf` | Matbaada boş kâğıda önceden antet basmak için (yalnız logo, çizgiler, alt bilgi). |

Kullanım: Word şablonunu açın, köşeli parantezli yerleri değiştirin, "Farklı Kaydet" ile yeni bir adla kaydedin.

## Zarflar (hazır zarfa baskı, taşma payı yok)
| Dosya | Ölçü | Ne için |
|---|---|---|
| `zarf/karacan-zarf-DL-220x110.pdf` | 220 × 110 mm | Üçe katlanmış A4 (mektup, fatura) |
| `zarf/karacan-zarf-C4-324x229.pdf` | 324 × 229 mm | Katlanmamış A4 (teklif dosyası, sözleşme) |

## Cepli sunum dosyası
| Dosya | Ölçü | Ne için |
|---|---|---|
| `dosya/karacan-sunum-dosyasi-dis-yuz-446x316.pdf` | Kapalı 220 × 310 mm; açık 440 × 310 + 3 mm taşma | Sol yarı arka kapak, sağ yarı ön kapak |
| `dosya/karacan-sunum-dosyasi-ic-cep-226x111.pdf` | 220 × 105 + 3 mm taşma | İç cep (kartvizit yuvası matbaa kalıbında) |

Not: Cepli dosyaların kesim ve katlama kalıbı matbaaya göre değişir. Matbaadan kalıp dosyasını isteyip bu tasarımın kalıba yerleştirilmesini isteyin; kalıp gelirse biz de yerleştirebiliriz.
Önerilen: 350 g mat kuşe + mat selefon veya dokulu krem karton.

## Kaşe
| Dosya | Ölçü |
|---|---|
| `kase/karacan-kase-58x24.pdf` | 58 × 24 mm, 1:1, tek renk |

Kaşeciye bu dosya verilir. Şirket kurulunca resmî kaşe ayrıca gerekir: ticaret unvanı, açık adres, vergi dairesi ve numarası, MERSİS numarası.

## Baskıdan önce
Telefon numarası (+90 534 263 47 18) işlendi. Açık adres her dosyada hâlâ yer tutucu (Gemlik / Bursa); gelince `./uret-baski.sh` ile hepsi birlikte güncellenecek.

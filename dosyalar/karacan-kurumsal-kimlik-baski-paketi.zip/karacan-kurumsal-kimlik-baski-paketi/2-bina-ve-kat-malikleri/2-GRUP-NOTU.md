# Karacan kurumsal kimlik — 2. grup (bina ve kat malikleri)

Word belgelerinde yazı tipleri dosyanın içine gömülüdür; ofis bilgisayarında kurulu olmasa da doğru görünür. Köşeli parantezli yerler doldurulur, "Farklı Kaydet" ile yeni adla saklanır.

| Dosya | Ne için |
|---|---|
| `bina/karacan-duyuru-sablon.docx` | Panoya asılacak duyurular (su kesintisi, bakım, temizlik, toplantı). İri yazı, bilgi kutusu, altta arıza hattı. |
| `bina/karacan-genel-kurul-cagrisi.docx` | 1. sayfa: kat malikleri kurulu toplantı çağrısı (birinci ve ikinci toplantı, sebep, gündem, vekâlet hatırlatması). 2. sayfa: imzalı çağrı tebliğ listesi. |
| `bina/karacan-hazirun-ve-tutanak.docx` | 1. sayfa: hazirun (katılım) listesi. Sonraki sayfalar: toplantı tutanağı (yeter sayı, divan, 5 gündem maddesi için görüşme–karar–oylama, imzalar). |
| `bina/karacan-bina-bilgi-karti-A5.pdf` | Asansöre ve girişe asılacak kart (A5, 3 mm taşma payı dahil 154 × 216 mm). Yöneticinin adı ve adresi Kat Mülkiyeti Kanunu md. 34 gereği girişte çerçeve içinde asılmak zorundadır; asılmazsa idari para cezası öngörülür. QR kod sitenin iletişim sayfasını açar. |

## Belgelerdeki yasal dayanaklar (634 sayılı KMK, güncel metin)
- md. 29: Olağan toplantı yönetim planındaki zamanda, yoksa her yıl ocakta (toplu yapıda en geç iki yılda bir). Olağanüstü toplantı çağrısı en az 15 gün önce, imza karşılığı ya da taahhütlü mektupla, sebep bildirilerek. İlk çağrıda ikinci toplantının yeri ve tarihi yazılır; iki toplantı arası en az 7 gün.
- md. 30: Yeter sayı, kat maliklerinin sayı ve arsa payı bakımından yarısından fazlası; ikinci toplantı en geç 15 gün sonra, katılanların salt çoğunluğu.
- md. 31: Vekâletle oy; bir kişi oyların %5'inden fazlası için vekil olamaz; 40 ve daha az bağımsız bölümlü yapıda bir kişi en fazla iki kat malikine vekâlet edebilir.
- md. 32: Kararlar sayfaları numaralı, noter onaylı karar defterine yazılıp katılanlarca imzalanır.
- md. 34: Yöneticinin adı, soyadı, iş ve ev adresi girişte çerçeve içinde asılır.

## Doldurulması gerekenler
Telefon numarası, açık iş adresi (kartta ve alt bilgilerde). Yönetici gerçek kişiyse kanun ev adresini de istiyor; bu konuyu İbrahim Bey'e danışın.
"24 saat içinde dönüş" sözü İbrahim Bey'in onayına bağlı.

## Yeniden üretme
`node bina/uret-belgeler.mjs` (Word belgeleri), kart için `bina-bilgi-karti.html` Chrome ile PDF'e basılır. Word önizlemesi: `node araclar/onizle-docx.mjs <dosya.docx> <cikti.png>`.

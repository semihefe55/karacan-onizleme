# Karacan kartvizit — matbaa notu

Ön yüz siyah zemin üzerine altın yaldız logo, arka yüz krem. Her baskı dosyasında 1. sayfa ön yüz, 2. sayfa arka yüzdür.

| Dosya | Sayfa ölçüsü | Ne zaman |
|---|---|---|
| `karacan-kartvizit-baski-3mm-tasmali.pdf` | 96 × 56 mm (her kenarda 3 mm taşma payı) | Matbaa "taşma payı ekleyin" diyorsa (çoğu matbaa) |
| `karacan-kartvizit-baski-net-90x50.pdf` | 90 × 50 mm | Matbaa net ölçü istiyorsa ya da payı kendisi ekliyorsa |
| `karacan-kartvizit-on-yuz-yaldiz-kalibi.pdf` | 96 × 56 mm | Altın yaldız (varak) kalıbı: siyah olan her yer yaldızlanır |

| | |
|---|---|
| Kesim ölçüsü | **90 × 50 mm** (kesim çizgisi PDF'e TrimBox olarak işlenmiştir) |
| Güvenli alan | Yazı ve logolar kesimden en az 4 mm içeride |
| Ön yüz | Siyah zemin; matbaadan **zengin siyah** isteyin (ör. C40 M30 Y30 K100), düz K100 gri görünür. Logo, KARACAN yazısı, altındaki çizgi ve slogan **altın yaldız**; binaların altın kenarları ve kaide de **altın yaldız**; siyah bina içleri ve "Site, Apartman ve İş Merkezi / Yönetim ve Danışmanlık" satırları normal baskı (yaldız değil). |
| Arka yüz | Krem zemin (#F6F2E9), normal dört renk baskı |
| Önerilen kâğıt | 350–400 g mat kuşe + çift yüz **soft-touch (kadife) selefon** + ön yüze **altın yaldız**. Daha lüks: kalın (600 g+) çift katlı kâğıt. |
| Yaldızsız baskı | Yaldız yapılmazsa altın tonlar normal baskıyla basılır; parlaklık olmaz ama düzgün görünür. |
| Renk | Dosya RGB; matbaa CMYK'ya çevirir. İlk baskıda prova istenmeli. |

**Bilgiler güncel (7 Ekim 2026):** telefon +90 534 263 47 18; adres Hamidiye Mah. Kuvayi Milliye Blv. No: 232/7, Gemlik / Bursa (iç kapı 7).
Kaynak dosya: `kartvizit.html`. Bilgi değişince `./uret.sh` üç PDF'i ve önizleme görselini yeniden üretir.
